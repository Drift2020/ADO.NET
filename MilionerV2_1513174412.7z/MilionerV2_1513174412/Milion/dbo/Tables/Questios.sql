﻿CREATE TABLE [dbo].[Questios] (
    [Questio]  NVARCHAR (255) NULL,
    [Answer_1] NVARCHAR (255) NULL,
    [Answer_2] NVARCHAR (255) NULL,
    [Answer_3] NVARCHAR (255) NULL,
    [Answer_4] NVARCHAR (255) NULL
);

